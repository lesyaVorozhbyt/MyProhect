//
//  ViewController.swift
//  DataBeetweenControllers
//
//  Created by Lesia Vorozhbyt on 23.02.2022.
//

import UIKit

class ListViewController: UIViewController {

    @IBOutlet weak var taskNameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

